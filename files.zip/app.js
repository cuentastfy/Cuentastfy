(() => {
  "use strict";
  const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  const LIMIT_MS = 30 * 60 * 1000;
  const LABEL = { disponible: "Disponible", en_uso: "En uso", utilizado: "Utilizado" };
  const $ = (s) => document.querySelector(s);

  let accounts = [];
  let offset = 0;                       // (hora servidor) - (hora navegador), en ms
  let fStatus = "todos", fProject = "todos";
  let expiring = false, reloadTimer = null, editingId = null;

  const serverNow = () => Date.now() + offset;
  const esc = (t) => String(t ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  function toast(msg, err) {
    const t = $("#toast");
    t.textContent = msg; t.className = "toast show" + (err ? " err" : "");
    clearTimeout(toast.t); toast.t = setTimeout(() => (t.className = "toast"), 2200);
  }

  /* ---------- Tiempo: SIEMPRE referido a la hora del servidor ---------- */
  async function syncTime() {
    const t0 = Date.now();
    const { data, error } = await sb.rpc("server_time");
    if (error || !data) return;
    const t1 = Date.now();
    offset = new Date(data).getTime() - (t0 + t1) / 2;   // compensa latencia y reloj desfasado
  }

  // Estado efectivo = estado guardado + comparación con used_at (hora de Supabase)
  function view(a) {
    if (a.status === "en_uso" && a.used_at) {
      const left = new Date(a.used_at).getTime() + LIMIT_MS - serverNow();
      return left <= 0 ? { s: "utilizado", left: 0 } : { s: "en_uso", left };
    }
    return { s: a.status, left: 0 };
  }

  async function expireInDb() {
    if (expiring) return; expiring = true;
    try { await sb.rpc("expire_accounts"); } finally { expiring = false; }
  }

  /* ---------- Carga y tiempo real ---------- */
  async function load() {
    await syncTime();
    await sb.rpc("expire_accounts");
    const { data, error } = await sb.from("accounts").select("*").order("created_at", { ascending: true });
    if (error) { toast("No se pudieron cargar las cuentas: " + error.message, true); return; }
    accounts = data || [];
    $("#sync").textContent = "Sincronizado";
    render();
  }
  const scheduleLoad = () => { clearTimeout(reloadTimer); reloadTimer = setTimeout(load, 250); };

  /* ---------- Render ---------- */
  function render() {
    const counts = { todos: accounts.length, disponible: 0, en_uso: 0, utilizado: 0 };
    accounts.forEach((a) => counts[view(a).s]++);
    const tiles = [["todos", "Todas"], ["disponible", "Disponibles"], ["en_uso", "En uso"], ["utilizado", "Utilizadas"]];
    $("#stats").innerHTML = tiles.map(([k, n]) =>
      `<button class="stat" data-k="${k}" aria-pressed="${fStatus === k}"><b>${counts[k]}</b><span>${n}</span></button>`).join("");

    const projects = [...new Set(accounts.map((a) => a.project).filter(Boolean))].sort();
    if (fProject !== "todos" && !projects.includes(fProject)) fProject = "todos";
    $("#fProject").innerHTML = `<option value="todos">Todos los proyectos</option>` +
      projects.map((p) => `<option ${p === fProject ? "selected" : ""}>${esc(p)}</option>`).join("");
    $("#projects").innerHTML = projects.map((p) => `<option value="${esc(p)}">`).join("");

    const list = accounts.filter((a) => (fStatus === "todos" || view(a).s === fStatus) && (fProject === "todos" || a.project === fProject));
    $("#grid").innerHTML = list.length ? list.map(card).join("") :
      `<p class="empty">${accounts.length ? "No hay cuentas con ese filtro." : "Aún no hay cuentas. Pulsa “Agregar cuenta” para empezar."}</p>`;
    tick();
  }

  function card(a) {
    const v = view(a);
    return `<article class="card" data-id="${a.id}" data-s="${v.s}">
      <div class="head">
        <div><h3>${esc(a.email)}</h3><span class="proj">${esc(a.project) || "Sin proyecto"}</span></div>
        <span class="badge"><i class="dot"></i>${LABEL[v.s]}</span>
      </div>
      <div class="timer" data-timer></div>
      <div class="bar"><i data-bar></i></div>
      <div class="copy">
        <button class="btn btn-blue" data-act="copy-email">Copiar correo</button>
        <button class="btn btn-red" data-act="copy-pass">Copiar clave</button>
      </div>
      <div class="mini">
        <button class="btn btn-ghost sm" data-act="reset">Reset</button>
        <button class="btn btn-ghost sm" data-act="edit">Editar</button>
        <button class="btn btn-ghost sm" data-act="del">Eliminar</button>
      </div>
    </article>`;
  }

  // Cada segundo: actualiza solo contadores; si alguien llega a 0, pasa a UTILIZADO
  function tick() {
    let changed = false;
    document.querySelectorAll(".card").forEach((el) => {
      const a = accounts.find((x) => x.id === el.dataset.id); if (!a) return;
      const v = view(a);
      if (a.status === "en_uso" && v.s === "utilizado") { a.status = "utilizado"; changed = true; return; }
      const t = el.querySelector("[data-timer]"), b = el.querySelector("[data-bar]");
      if (v.s === "en_uso") {
        const m = Math.floor(v.left / 60000), s = Math.floor((v.left % 60000) / 1000);
        t.textContent = `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")} restantes`;
        b.style.width = (v.left / LIMIT_MS) * 100 + "%";
      } else {
        t.textContent = v.s === "utilizado" ? "Agotada · usa Reset para reactivarla" : "Lista para usar";
        b.style.width = "0";
      }
    });
    if (changed) { expireInDb().then(scheduleLoad); render(); }
  }

  /* ---------- Copiar + marcar EN USO (timestamp lo pone el servidor) ---------- */
  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); return true; }
    catch {
      const ta = Object.assign(document.createElement("textarea"), { value: text });
      ta.style.cssText = "position:fixed;opacity:0"; document.body.appendChild(ta); ta.select();
      const ok = document.execCommand("copy"); ta.remove(); return ok;
    }
  }

  async function copyField(a, field) {
    if (!(await copyText(a[field]))) return toast("No se pudo copiar al portapapeles", true);
    toast(field === "email" ? "Correo copiado" : "Clave copiada");
    const { data, error } = await sb.rpc("mark_in_use", { p_id: a.id });
    if (error) return toast("Copiado, pero no se pudo actualizar el estado: " + error.message, true);
    if (data && data.id) { Object.assign(a, data); await syncTime(); render(); }
  }

  /* ---------- Eventos ---------- */
  $("#grid").addEventListener("click", async (e) => {
    const btn = e.target.closest("[data-act]"); if (!btn) return;
    const a = accounts.find((x) => x.id === btn.closest(".card").dataset.id); if (!a) return;
    const act = btn.dataset.act;
    if (act === "copy-email") copyField(a, "email");
    if (act === "copy-pass") copyField(a, "password");
    if (act === "edit") openModal(a);
    if (act === "reset") {
      const { error } = await sb.rpc("reset_accounts", { p_id: a.id });
      error ? toast(error.message, true) : (toast("Cuenta disponible de nuevo"), load());
    }
    if (act === "del" && confirm(`¿Eliminar ${a.email}? Esta acción no se puede deshacer.`)) {
      const { error } = await sb.from("accounts").delete().eq("id", a.id);
      error ? toast(error.message, true) : (toast("Cuenta eliminada"), load());
    }
  });

  $("#stats").addEventListener("click", (e) => {
    const b = e.target.closest(".stat"); if (b) { fStatus = b.dataset.k; render(); }
  });
  $("#fProject").addEventListener("change", (e) => { fProject = e.target.value; render(); });

  $("#btnResetAll").addEventListener("click", async () => {
    if (!confirm("¿Volver TODAS las cuentas a Disponible?")) return;
    const { error } = await sb.rpc("reset_accounts");
    error ? toast(error.message, true) : (toast("Todas las cuentas están disponibles"), load());
  });

  /* ---------- Modal agregar / editar ---------- */
  const modal = $("#modal");
  function openModal(a) {
    editingId = a ? a.id : null;
    $("#mTitle").textContent = a ? "Editar cuenta" : "Agregar cuenta";
    $("#aEmail").value = a?.email || ""; $("#aPass").value = a?.password || ""; $("#aProject").value = a?.project || "";
    modal.showModal(); $("#aEmail").focus();
  }
  $("#btnAdd").addEventListener("click", () => openModal(null));
  $("#mCancel").addEventListener("click", () => modal.close());
  $("#accForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const row = { email: $("#aEmail").value.trim(), password: $("#aPass").value, project: $("#aProject").value.trim() };
    const { error } = editingId
      ? await sb.from("accounts").update(row).eq("id", editingId)
      : await sb.from("accounts").insert(row);          // entra como "disponible" por defecto
    if (error) return toast(error.message, true);
    modal.close(); toast("Cuenta guardada"); load();
  });

  /* ---------- Autenticación ---------- */
  let channel = null;
  async function showApp(session) {
    $("#login").classList.toggle("hidden", !!session);
    $("#app").classList.toggle("hidden", !session);
    if (channel) { sb.removeChannel(channel); channel = null; }
    if (!session) { accounts = []; return; }
    await load();
    channel = sb.channel("accounts-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "accounts" }, scheduleLoad)
      .subscribe();
  }

  $("#loginForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("#lBtn"); btn.disabled = true; $("#lError").textContent = "";
    const { error } = await sb.auth.signInWithPassword({ email: $("#lEmail").value.trim(), password: $("#lPass").value });
    btn.disabled = false;
    if (error) $("#lError").textContent = "Correo o contraseña incorrectos.";
  });
  $("#btnOut").addEventListener("click", () => sb.auth.signOut());

  sb.auth.onAuthStateChange((_evt, session) => { showApp(session); });

  // Al volver a la pestaña o recuperar internet: resincroniza hora y estados
  document.addEventListener("visibilitychange", () => { if (!document.hidden && !$("#app").classList.contains("hidden")) load(); });
  window.addEventListener("online", load);
  setInterval(() => { if (!$("#app").classList.contains("hidden")) tick(); }, 1000);
  setInterval(() => { if (!$("#app").classList.contains("hidden")) load(); }, 60000);   // red de seguridad
})();
