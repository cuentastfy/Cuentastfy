# Vault · Pool de cuentas

HTML + CSS + JS puro · Supabase (Auth + BD + Realtime) · GitHub · Vercel.

## Estructura

```
vault-cuentas/
├── index.html
├── supabase.sql
├── css/styles.css
└── js/
    ├── config.js   ← aquí pegas tu URL y anon key
    └── app.js
```

## 1. Supabase

1. Crea un proyecto en supabase.com.
2. **SQL Editor → New query**: pega todo `supabase.sql` y pulsa **Run**.
3. **Authentication → Users → Add user**: crea tu usuario (correo + contraseña, marca *Auto Confirm*).
4. **Authentication → Sign In / Providers → Email**: desactiva **Allow new users to sign up** para que nadie más pueda registrarse.
5. **Project Settings → API**: copia *Project URL* y *anon public key* en `js/config.js`.

## 2. GitHub

```bash
cd vault-cuentas
git init && git add . && git commit -m "Vault inicial"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/vault-cuentas.git
git push -u origin main
```

Usa un repositorio **privado**.

## 3. Vercel

1. vercel.com → **Add New → Project** → importa el repositorio.
2. *Framework Preset*: **Other**. Sin build command, sin output directory.
3. **Deploy**. Cada `git push` vuelve a publicar solo.

## Cómo funciona la regla de 30 minutos

- Al copiar correo o clave, la app llama a `mark_in_use`: el servidor guarda `status = en_uso` y `used_at = now()` (hora de Supabase, no del navegador).
- La pantalla calcula `used_at + 30 min − hora del servidor`. La hora del servidor se sincroniza al cargar, así un celular con el reloj mal puesto no afecta.
- Al llegar a 0, la tarjeta pasa a **Utilizado** y la app llama a `expire_accounts()` para registrarlo en la base de datos.
- Si recargas, cierras el navegador o abres desde el celular, el contador se recalcula desde `used_at`.
- Copiar de nuevo una cuenta que ya está **En uso** no reinicia el contador.
- Opcional: activa `pg_cron` y descomenta el último bloque del SQL para que la BD marque Utilizado aunque no tengas la app abierta.

## Seguridad

- Las contraseñas se guardan como texto en la tabla, protegidas por RLS (solo tu usuario las lee). Si quieres más protección, avísame y añadimos cifrado.
- Mantén desactivado el registro público y el repositorio privado.
