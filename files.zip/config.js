// Supabase > Project Settings > API
// La "anon key" es pública por diseño; la protección real son las políticas RLS del SQL.
const SUPABASE_URL = "https://TU-PROYECTO.supabase.co";
const SUPABASE_ANON_KEY = "TU_ANON_PUBLIC_KEY";
